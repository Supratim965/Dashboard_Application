"use client"

import { useState, useCallback } from "react"
import { FileUpload } from "@/components/file-upload"
import { Dashboard } from "@/components/dashboard"
import { Spinner } from "@/components/ui/spinner"
import {
  parseCSV,
  parseExcel,
  parseJSON,
  type ParsedData,
} from "@/lib/data-utils"
import { BarChart3, FileSpreadsheet, Sparkles, Zap } from "lucide-react"

export default function HomePage() {
  const [parsedData, setParsedData] = useState<ParsedData | null>(null)
  const [fileName, setFileName] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleFileSelect = useCallback(async (file: File) => {
    setIsLoading(true)
    setError(null)
    setFileName(file.name)

    try {
      let data: ParsedData

      if (file.name.endsWith(".csv") || file.type === "text/csv") {
        const text = await file.text()
        data = parseCSV(text)
      } else if (
        file.name.endsWith(".xlsx") ||
        file.name.endsWith(".xls") ||
        file.type.includes("spreadsheet") ||
        file.type.includes("excel")
      ) {
        const buffer = await file.arrayBuffer()
        data = parseExcel(buffer)
      } else if (file.name.endsWith(".json") || file.type === "application/json") {
        const text = await file.text()
        data = parseJSON(text)
      } else {
        throw new Error(
          "Unsupported file format. Please upload CSV, Excel, or JSON files."
        )
      }

      if (data.rows.length === 0) {
        throw new Error("The file appears to be empty or has no valid data.")
      }

      setParsedData(data)
    } catch (err) {
      console.error("Error parsing file:", err)
      setError(err instanceof Error ? err.message : "Failed to parse file")
      setParsedData(null)
    } finally {
      setIsLoading(false)
    }
  }, [])

  const handleReset = useCallback(() => {
    setParsedData(null)
    setFileName("")
    setError(null)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <BarChart3 className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">
              DataViz Analytics
            </span>
          </div>
          {parsedData && (
            <div className="text-sm text-muted-foreground">
              <span className="hidden sm:inline">Analyzing: </span>
              <span className="font-medium text-foreground">{fileName}</span>
            </div>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
            <Spinner className="h-12 w-12 text-primary" />
            <div className="text-center">
              <h2 className="text-xl font-semibold text-foreground">
                Analyzing your data...
              </h2>
              <p className="text-muted-foreground mt-1">
                Please wait while we process your file
              </p>
            </div>
          </div>
        ) : parsedData ? (
          <Dashboard
            data={parsedData}
            fileName={fileName}
            onReset={handleReset}
          />
        ) : (
          <div className="max-w-4xl mx-auto space-y-12">
            {/* Hero Section */}
            <div className="text-center space-y-4 py-8">
              <h1 className="text-4xl font-bold text-foreground sm:text-5xl text-balance">
                Transform Your Data Into
                <span className="text-primary"> Insights</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
                Upload your CSV, Excel, or JSON files and instantly generate
                interactive dashboards with KPIs, charts, and analytics.
              </p>
            </div>

            {/* Upload Section */}
            <FileUpload onFileSelect={handleFileSelect} isLoading={isLoading} />

            {error && (
              <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-center">
                {error}
              </div>
            )}

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-card border border-border">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-4">
                  <FileSpreadsheet className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">
                  Multiple Formats
                </h3>
                <p className="text-sm text-muted-foreground">
                  Support for CSV, Excel (.xlsx, .xls), and JSON files
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-card border border-border">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-4">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">
                  Auto KPI Detection
                </h3>
                <p className="text-sm text-muted-foreground">
                  Automatically identifies and calculates key metrics
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-card border border-border">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-4">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">
                  Interactive Charts
                </h3>
                <p className="text-sm text-muted-foreground">
                  Dynamic visualizations with filters and sliders
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          DataViz Analytics — Transform your data into actionable insights
        </div>
      </footer>
    </div>
  )
}
