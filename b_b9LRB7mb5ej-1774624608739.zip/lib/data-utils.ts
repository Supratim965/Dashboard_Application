import * as XLSX from "xlsx"

export interface ParsedData {
  columns: string[]
  rows: Record<string, unknown>[]
  numericColumns: string[]
  categoricalColumns: string[]
  dateColumns: string[]
}

export interface KPI {
  name: string
  value: string | number
  change?: number
  changeType?: "increase" | "decrease" | "neutral"
  description: string
}

export interface ChartData {
  type: "bar" | "line" | "pie" | "area"
  title: string
  data: Record<string, unknown>[]
  xKey: string
  yKeys: string[]
  description: string
}

export function parseCSV(content: string): ParsedData {
  const lines = content.trim().split("\n")
  if (lines.length === 0) throw new Error("Empty CSV file")

  const headers = lines[0].split(",").map((h) => h.trim().replace(/^"|"$/g, ""))
  const rows: Record<string, unknown>[] = []

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i])
    if (values.length === headers.length) {
      const row: Record<string, unknown> = {}
      headers.forEach((header, index) => {
        row[header] = parseValue(values[index])
      })
      rows.push(row)
    }
  }

  return analyzeData(headers, rows)
}

function parseCSVLine(line: string): string[] {
  const values: string[] = []
  let current = ""
  let inQuotes = false

  for (let i = 0; i < line.length; i++) {
    const char = line[i]
    if (char === '"') {
      inQuotes = !inQuotes
    } else if (char === "," && !inQuotes) {
      values.push(current.trim())
      current = ""
    } else {
      current += char
    }
  }
  values.push(current.trim())
  return values
}

export function parseExcel(buffer: ArrayBuffer): ParsedData {
  const workbook = XLSX.read(buffer, { type: "array" })
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
  const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 }) as unknown[][]

  if (jsonData.length === 0) throw new Error("Empty Excel file")

  const headers = (jsonData[0] as string[]).map((h) => String(h || "").trim())
  const rows: Record<string, unknown>[] = []

  for (let i = 1; i < jsonData.length; i++) {
    const rowData = jsonData[i] as unknown[]
    if (rowData && rowData.length > 0) {
      const row: Record<string, unknown> = {}
      headers.forEach((header, index) => {
        if (header) {
          row[header] = parseValue(rowData[index])
        }
      })
      rows.push(row)
    }
  }

  return analyzeData(headers.filter(Boolean), rows)
}

export function parseJSON(content: string): ParsedData {
  const data = JSON.parse(content)

  let rows: Record<string, unknown>[]
  if (Array.isArray(data)) {
    rows = data
  } else if (typeof data === "object" && data !== null) {
    const arrayKey = Object.keys(data).find((key) => Array.isArray(data[key]))
    if (arrayKey) {
      rows = data[arrayKey]
    } else {
      rows = [data]
    }
  } else {
    throw new Error("Invalid JSON structure")
  }

  if (rows.length === 0) throw new Error("Empty JSON data")

  const headers = [...new Set(rows.flatMap((row) => Object.keys(row)))]
  return analyzeData(headers, rows)
}

function parseValue(value: unknown): unknown {
  if (value === null || value === undefined || value === "") return null

  const stringValue = String(value).trim()

  // Try to parse as number
  const num = Number(stringValue.replace(/,/g, ""))
  if (!isNaN(num) && stringValue !== "") return num

  // Try to parse as date
  const date = new Date(stringValue)
  if (!isNaN(date.getTime()) && stringValue.match(/\d{4}|\d{1,2}[/-]\d{1,2}/)) {
    return date.toISOString()
  }

  return stringValue
}

function analyzeData(columns: string[], rows: Record<string, unknown>[]): ParsedData {
  const numericColumns: string[] = []
  const categoricalColumns: string[] = []
  const dateColumns: string[] = []

  columns.forEach((col) => {
    const values = rows.map((row) => row[col]).filter((v) => v !== null && v !== undefined)
    if (values.length === 0) return

    const numericCount = values.filter((v) => typeof v === "number").length
    const dateCount = values.filter((v) => typeof v === "string" && !isNaN(Date.parse(v as string))).length

    if (numericCount > values.length * 0.8) {
      numericColumns.push(col)
    } else if (dateCount > values.length * 0.8) {
      dateColumns.push(col)
    } else {
      categoricalColumns.push(col)
    }
  })

  return {
    columns,
    rows,
    numericColumns,
    categoricalColumns,
    dateColumns,
  }
}

export function generateKPIs(data: ParsedData): KPI[] {
  const kpis: KPI[] = []

  // Total Records
  kpis.push({
    name: "Total Records",
    value: data.rows.length.toLocaleString(),
    description: "Total number of data entries",
  })

  // Generate KPIs for numeric columns
  data.numericColumns.slice(0, 5).forEach((col) => {
    const values = data.rows
      .map((row) => row[col])
      .filter((v) => typeof v === "number") as number[]

    if (values.length > 0) {
      const sum = values.reduce((a, b) => a + b, 0)
      const avg = sum / values.length
      const max = Math.max(...values)
      const min = Math.min(...values)

      kpis.push({
        name: `Total ${col}`,
        value: formatNumber(sum),
        description: `Sum of all ${col} values`,
      })

      kpis.push({
        name: `Avg ${col}`,
        value: formatNumber(avg),
        description: `Average ${col} value`,
      })

      if (values.length >= 2) {
        const midpoint = Math.floor(values.length / 2)
        const firstHalf = values.slice(0, midpoint)
        const secondHalf = values.slice(midpoint)
        const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length
        const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length
        const change = ((secondAvg - firstAvg) / firstAvg) * 100

        if (!isNaN(change) && isFinite(change)) {
          kpis[kpis.length - 1].change = Math.abs(change)
          kpis[kpis.length - 1].changeType = change >= 0 ? "increase" : "decrease"
        }
      }

      kpis.push({
        name: `Max ${col}`,
        value: formatNumber(max),
        description: `Maximum ${col} value`,
      })

      kpis.push({
        name: `Min ${col}`,
        value: formatNumber(min),
        description: `Minimum ${col} value`,
      })
    }
  })

  // Generate KPIs for categorical columns
  data.categoricalColumns.slice(0, 2).forEach((col) => {
    const uniqueValues = new Set(data.rows.map((row) => row[col]).filter(Boolean))
    kpis.push({
      name: `Unique ${col}`,
      value: uniqueValues.size.toLocaleString(),
      description: `Number of unique ${col} values`,
    })
  })

  return kpis.slice(0, 12)
}

function formatNumber(num: number): string {
  if (Math.abs(num) >= 1000000) {
    return (num / 1000000).toFixed(2) + "M"
  } else if (Math.abs(num) >= 1000) {
    return (num / 1000).toFixed(2) + "K"
  } else if (Number.isInteger(num)) {
    return num.toLocaleString()
  } else {
    return num.toFixed(2)
  }
}

export function generateCharts(data: ParsedData): ChartData[] {
  const charts: ChartData[] = []

  // Bar chart for top categorical + numeric combination
  if (data.categoricalColumns.length > 0 && data.numericColumns.length > 0) {
    const catCol = data.categoricalColumns[0]
    const numCol = data.numericColumns[0]

    const aggregated = aggregateData(data.rows, catCol, numCol)
    const topData = aggregated.slice(0, 10)

    charts.push({
      type: "bar",
      title: `${numCol} by ${catCol}`,
      data: topData,
      xKey: catCol,
      yKeys: [numCol],
      description: `Distribution of ${numCol} across different ${catCol} categories`,
    })
  }

  // Line chart for time-series if date column exists
  if (data.dateColumns.length > 0 && data.numericColumns.length > 0) {
    const dateCol = data.dateColumns[0]
    const numCol = data.numericColumns[0]

    const sortedData = [...data.rows]
      .filter((row) => row[dateCol] && row[numCol])
      .sort((a, b) => new Date(a[dateCol] as string).getTime() - new Date(b[dateCol] as string).getTime())
      .slice(0, 50)
      .map((row) => ({
        ...row,
        [dateCol]: new Date(row[dateCol] as string).toLocaleDateString(),
      }))

    if (sortedData.length > 2) {
      charts.push({
        type: "line",
        title: `${numCol} Over Time`,
        data: sortedData,
        xKey: dateCol,
        yKeys: [numCol],
        description: `Trend of ${numCol} over time`,
      })
    }
  }

  // Area chart for multiple numeric columns
  if (data.numericColumns.length >= 2) {
    const xCol = data.categoricalColumns[0] || data.dateColumns[0]
    const yKeys = data.numericColumns.slice(0, 3)

    if (xCol) {
      const aggregatedData = data.rows.slice(0, 20).map((row) => {
        const result: Record<string, unknown> = { [xCol]: row[xCol] }
        yKeys.forEach((key) => {
          result[key] = row[key]
        })
        return result
      })

      charts.push({
        type: "area",
        title: `Multi-metric Analysis`,
        data: aggregatedData,
        xKey: xCol,
        yKeys,
        description: `Comparison of ${yKeys.join(", ")} metrics`,
      })
    }
  }

  // Pie chart for categorical distribution
  if (data.categoricalColumns.length > 0) {
    const catCol = data.categoricalColumns[0]
    const counts: Record<string, number> = {}

    data.rows.forEach((row) => {
      const value = String(row[catCol] || "Unknown")
      counts[value] = (counts[value] || 0) + 1
    })

    const pieData = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([name, value]) => ({ name, value }))

    charts.push({
      type: "pie",
      title: `${catCol} Distribution`,
      data: pieData,
      xKey: "name",
      yKeys: ["value"],
      description: `Distribution of records by ${catCol}`,
    })
  }

  // Additional bar chart for second numeric column
  if (data.categoricalColumns.length > 0 && data.numericColumns.length > 1) {
    const catCol = data.categoricalColumns[0]
    const numCol = data.numericColumns[1]

    const aggregated = aggregateData(data.rows, catCol, numCol)
    const topData = aggregated.slice(0, 10)

    charts.push({
      type: "bar",
      title: `${numCol} by ${catCol}`,
      data: topData,
      xKey: catCol,
      yKeys: [numCol],
      description: `Distribution of ${numCol} across different ${catCol} categories`,
    })
  }

  return charts
}

function aggregateData(
  rows: Record<string, unknown>[],
  groupBy: string,
  valueCol: string
): Record<string, unknown>[] {
  const aggregated: Record<string, { sum: number; count: number }> = {}

  rows.forEach((row) => {
    const key = String(row[groupBy] || "Unknown")
    const value = Number(row[valueCol]) || 0

    if (!aggregated[key]) {
      aggregated[key] = { sum: 0, count: 0 }
    }
    aggregated[key].sum += value
    aggregated[key].count += 1
  })

  return Object.entries(aggregated)
    .map(([key, { sum }]) => ({
      [groupBy]: key,
      [valueCol]: sum,
    }))
    .sort((a, b) => (b[valueCol] as number) - (a[valueCol] as number))
}
