"use client"

import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import type { ParsedData } from "@/lib/data-utils"

export interface FilterState {
  numericFilters: Record<string, [number, number]>
  categoricalFilters: Record<string, string>
}

interface FilterControlsProps {
  data: ParsedData
  filters: FilterState
  onFiltersChange: (filters: FilterState) => void
}

export function FilterControls({
  data,
  filters,
  onFiltersChange,
}: FilterControlsProps) {
  const numericRanges = useMemo(() => {
    const ranges: Record<string, { min: number; max: number }> = {}
    
    data.numericColumns.slice(0, 3).forEach((col) => {
      const values = data.rows
        .map((row) => row[col])
        .filter((v): v is number => typeof v === "number")
      
      if (values.length > 0) {
        ranges[col] = {
          min: Math.min(...values),
          max: Math.max(...values),
        }
      }
    })
    
    return ranges
  }, [data])

  const categoricalOptions = useMemo(() => {
    const options: Record<string, string[]> = {}
    
    data.categoricalColumns.slice(0, 3).forEach((col) => {
      const uniqueValues = [...new Set(
        data.rows
          .map((row) => row[col])
          .filter((v): v is string => typeof v === "string")
      )].slice(0, 20)
      
      if (uniqueValues.length > 0) {
        options[col] = uniqueValues
      }
    })
    
    return options
  }, [data])

  const handleNumericChange = (column: string, value: [number, number]) => {
    onFiltersChange({
      ...filters,
      numericFilters: {
        ...filters.numericFilters,
        [column]: value,
      },
    })
  }

  const handleCategoricalChange = (column: string, value: string) => {
    onFiltersChange({
      ...filters,
      categoricalFilters: {
        ...filters.categoricalFilters,
        [column]: value,
      },
    })
  }

  const removeNumericFilter = (column: string) => {
    const newFilters = { ...filters.numericFilters }
    delete newFilters[column]
    onFiltersChange({
      ...filters,
      numericFilters: newFilters,
    })
  }

  const removeCategoricalFilter = (column: string) => {
    const newFilters = { ...filters.categoricalFilters }
    delete newFilters[column]
    onFiltersChange({
      ...filters,
      categoricalFilters: newFilters,
    })
  }

  const activeFiltersCount =
    Object.keys(filters.numericFilters).length +
    Object.keys(filters.categoricalFilters).filter(
      (k) => filters.categoricalFilters[k] !== "all"
    ).length

  const hasFilters =
    Object.keys(numericRanges).length > 0 ||
    Object.keys(categoricalOptions).length > 0

  if (!hasFilters) return null

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-foreground">
            Filters
          </CardTitle>
          {activeFiltersCount > 0 && (
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              {activeFiltersCount} active
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Numeric Sliders */}
        {Object.entries(numericRanges).map(([column, range]) => {
          const currentValue = filters.numericFilters[column] || [
            range.min,
            range.max,
          ]
          const isActive =
            currentValue[0] !== range.min || currentValue[1] !== range.max

          return (
            <div key={column} className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium text-foreground">
                  {column}
                </Label>
                {isActive && (
                  <button
                    onClick={() => removeNumericFilter(column)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <Slider
                value={currentValue}
                min={range.min}
                max={range.max}
                step={(range.max - range.min) / 100}
                onValueChange={(value) =>
                  handleNumericChange(column, value as [number, number])
                }
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{currentValue[0].toLocaleString()}</span>
                <span>{currentValue[1].toLocaleString()}</span>
              </div>
            </div>
          )
        })}

        {/* Categorical Selects */}
        {Object.entries(categoricalOptions).map(([column, options]) => {
          const currentValue = filters.categoricalFilters[column] || "all"
          const isActive = currentValue !== "all"

          return (
            <div key={column} className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium text-foreground">
                  {column}
                </Label>
                {isActive && (
                  <button
                    onClick={() => removeCategoricalFilter(column)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <Select
                value={currentValue}
                onValueChange={(value) => handleCategoricalChange(column, value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={`Select ${column}`} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All {column}</SelectItem>
                  {options.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
