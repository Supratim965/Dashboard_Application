"use client"

import { useState, useMemo, useCallback } from "react"
import { KPICards } from "./kpi-cards"
import { ChartDisplay } from "./chart-display"
import { DataTable } from "./data-table"
import { FilterControls, type FilterState } from "./filter-controls"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Download, BarChart3, Table, Filter, RefreshCcw, FileSpreadsheet, FileText, ChevronDown } from "lucide-react"
import {
  type ParsedData,
  type KPI,
  type ChartData,
  generateKPIs,
  generateCharts,
} from "@/lib/data-utils"
import * as XLSX from "xlsx"

interface DashboardProps {
  data: ParsedData
  fileName: string
  onReset: () => void
}

export function Dashboard({ data, fileName, onReset }: DashboardProps) {
  const [isDownloading, setIsDownloading] = useState(false)
  const [filters, setFilters] = useState<FilterState>({
    numericFilters: {},
    categoricalFilters: {},
  })

  const filteredData = useMemo(() => {
    let rows = [...data.rows]

    // Apply numeric filters
    Object.entries(filters.numericFilters).forEach(([column, [min, max]]) => {
      rows = rows.filter((row) => {
        const value = row[column]
        if (typeof value !== "number") return true
        return value >= min && value <= max
      })
    })

    // Apply categorical filters
    Object.entries(filters.categoricalFilters).forEach(([column, value]) => {
      if (value && value !== "all") {
        rows = rows.filter((row) => String(row[column]) === value)
      }
    })

    return {
      ...data,
      rows,
    }
  }, [data, filters])

  const kpis: KPI[] = useMemo(() => generateKPIs(filteredData), [filteredData])
  const charts: ChartData[] = useMemo(
    () => generateCharts(filteredData),
    [filteredData]
  )

  const baseFileName = fileName.replace(/\.[^/.]+$/, "")

  const downloadAsCSV = useCallback(() => {
    setIsDownloading(true)
    try {
      // Create CSV content with filtered data
      const headers = filteredData.columns.join(",")
      const rows = filteredData.rows.map(row =>
        filteredData.columns.map(col => {
          const value = row[col]
          // Escape values containing commas or quotes
          if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`
          }
          return value ?? ""
        }).join(",")
      ).join("\n")

      const csvContent = `${headers}\n${rows}`
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const link = document.createElement("a")
      link.href = URL.createObjectURL(blob)
      link.download = `${baseFileName}-dashboard.csv`
      link.click()
      URL.revokeObjectURL(link.href)
    } catch (error) {
      console.error("Error downloading CSV:", error)
    } finally {
      setIsDownloading(false)
    }
  }, [filteredData, baseFileName])

  const downloadAsExcel = useCallback(() => {
    setIsDownloading(true)
    try {
      // Create workbook with multiple sheets
      const workbook = XLSX.utils.book_new()

      // Sheet 1: Filtered Data
      const dataSheet = XLSX.utils.json_to_sheet(filteredData.rows)
      XLSX.utils.book_append_sheet(workbook, dataSheet, "Data")

      // Sheet 2: KPIs Summary
      const kpiData = kpis.map(kpi => ({
        "KPI Name": kpi.label,
        "Value": kpi.value,
        "Change": kpi.change ? `${kpi.change > 0 ? "+" : ""}${kpi.change.toFixed(1)}%` : "N/A",
        "Type": kpi.type,
      }))
      const kpiSheet = XLSX.utils.json_to_sheet(kpiData)
      XLSX.utils.book_append_sheet(workbook, kpiSheet, "KPIs")

      // Sheet 3: Data Summary
      const summaryData = [
        { "Metric": "Total Records", "Value": filteredData.rows.length },
        { "Metric": "Original Records", "Value": data.rows.length },
        { "Metric": "Columns", "Value": filteredData.columns.length },
        { "Metric": "Numeric Columns", "Value": filteredData.numericColumns.length },
        { "Metric": "Categorical Columns", "Value": filteredData.categoricalColumns.length },
        { "Metric": "Date Columns", "Value": filteredData.dateColumns.length },
      ]
      const summarySheet = XLSX.utils.json_to_sheet(summaryData)
      XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary")

      // Download
      XLSX.writeFile(workbook, `${baseFileName}-dashboard.xlsx`)
    } catch (error) {
      console.error("Error downloading Excel:", error)
    } finally {
      setIsDownloading(false)
    }
  }, [filteredData, kpis, data.rows.length, baseFileName])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-card p-4 rounded-lg border border-border">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Data Analytics Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Analyzing: <span className="font-medium text-foreground">{fileName}</span>
            <span className="mx-2">•</span>
            <span>{filteredData.rows.length.toLocaleString()} records</span>
            {filteredData.rows.length !== data.rows.length && (
              <span className="text-primary ml-1">
                (filtered from {data.rows.length.toLocaleString()})
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={onReset}>
            <RefreshCcw className="mr-2 h-4 w-4" />
            New Analysis
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button disabled={isDownloading}>
                <Download className="mr-2 h-4 w-4" />
                {isDownloading ? "Downloading..." : "Download Data"}
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={downloadAsCSV}>
                <FileText className="mr-2 h-4 w-4" />
                Download as CSV
              </DropdownMenuItem>
              <DropdownMenuItem onClick={downloadAsExcel}>
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Download as Excel
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="space-y-6 p-1">
        {/* KPI Cards */}
        <section>
          <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Key Performance Indicators
          </h2>
          <KPICards kpis={kpis} />
        </section>

        {/* Tabs for Charts, Table, and Filters */}
        <Tabs defaultValue="charts" className="space-y-4">
          <TabsList className="bg-secondary">
            <TabsTrigger value="charts" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Charts
            </TabsTrigger>
            <TabsTrigger value="table" className="flex items-center gap-2">
              <Table className="h-4 w-4" />
              Data Table
            </TabsTrigger>
            <TabsTrigger value="filters" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filters
            </TabsTrigger>
          </TabsList>

          <TabsContent value="charts" className="space-y-6">
            {charts.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {charts.map((chart, index) => (
                  <ChartDisplay key={index} chart={chart} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                No charts could be generated from this data. Please ensure your
                data contains numeric and/or categorical columns.
              </div>
            )}
          </TabsContent>

          <TabsContent value="table">
            <DataTable data={filteredData} />
          </TabsContent>

          <TabsContent value="filters">
            <div className="max-w-md">
              <FilterControls
                data={data}
                filters={filters}
                onFiltersChange={setFilters}
              />
              {Object.keys(filters.numericFilters).length === 0 &&
                Object.keys(filters.categoricalFilters).filter(
                  (k) => filters.categoricalFilters[k] !== "all"
                ).length === 0 && (
                  <p className="text-sm text-muted-foreground mt-4 text-center">
                    Adjust the sliders and dropdowns to filter your data
                  </p>
                )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
