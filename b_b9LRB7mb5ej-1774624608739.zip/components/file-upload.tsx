"use client"

import { useCallback, useState } from "react"
import { Upload, FileSpreadsheet, FileJson, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface FileUploadProps {
  onFileSelect: (file: File) => void
  isLoading?: boolean
}

export function FileUpload({ onFileSelect, isLoading }: FileUploadProps) {
  const [dragActive, setDragActive] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const validateFile = (file: File): boolean => {
    const validTypes = [
      "text/csv",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/json",
    ]
    const validExtensions = [".csv", ".xlsx", ".xls", ".json"]
    
    const hasValidType = validTypes.includes(file.type)
    const hasValidExtension = validExtensions.some((ext) =>
      file.name.toLowerCase().endsWith(ext)
    )
    
    return hasValidType || hasValidExtension
  }

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      setDragActive(false)

      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        const file = e.dataTransfer.files[0]
        if (validateFile(file)) {
          setSelectedFile(file)
          onFileSelect(file)
        }
      }
    },
    [onFileSelect]
  )

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault()
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      if (validateFile(file)) {
        setSelectedFile(file)
        onFileSelect(file)
      }
    }
  }

  const removeFile = () => {
    setSelectedFile(null)
  }

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith(".json")) {
      return <FileJson className="h-8 w-8 text-primary" />
    }
    return <FileSpreadsheet className="h-8 w-8 text-primary" />
  }

  return (
    <Card
      className={cn(
        "border-2 border-dashed transition-all duration-200",
        dragActive
          ? "border-primary bg-primary/5"
          : "border-border hover:border-primary/50",
        isLoading && "opacity-50 pointer-events-none"
      )}
    >
      <CardContent className="p-8">
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className="flex flex-col items-center justify-center gap-4"
        >
          {selectedFile ? (
            <div className="flex items-center gap-4 p-4 bg-secondary rounded-lg w-full max-w-md">
              {getFileIcon(selectedFile.name)}
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">
                  {selectedFile.name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(2)} KB
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={removeFile}
                disabled={isLoading}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <>
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
                <Upload className="h-10 w-10 text-primary" />
              </div>
              <div className="text-center">
                <p className="text-lg font-medium text-foreground">
                  Drag and drop your file here
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Supports CSV, Excel (.xlsx, .xls), and JSON files
                </p>
              </div>
            </>
          )}
          
          <div className="flex items-center gap-4 mt-2">
            <div className="h-px flex-1 bg-border w-20" />
            <span className="text-sm text-muted-foreground">or</span>
            <div className="h-px flex-1 bg-border w-20" />
          </div>

          <label htmlFor="file-upload">
            <input
              id="file-upload"
              type="file"
              className="sr-only"
              accept=".csv,.xlsx,.xls,.json,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,application/json"
              onChange={handleChange}
              disabled={isLoading}
            />
            <Button
              type="button"
              variant="default"
              size="lg"
              disabled={isLoading}
              className="cursor-pointer"
              onClick={() => document.getElementById("file-upload")?.click()}
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload File
            </Button>
          </label>

          <div className="flex flex-wrap items-center justify-center gap-4 mt-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <FileSpreadsheet className="h-4 w-4" />
              <span>CSV</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <FileSpreadsheet className="h-4 w-4" />
              <span>Excel</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <FileJson className="h-4 w-4" />
              <span>JSON</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
