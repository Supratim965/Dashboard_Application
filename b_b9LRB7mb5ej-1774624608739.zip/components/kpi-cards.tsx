"use client"

import { TrendingUp, TrendingDown, Minus } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import type { KPI } from "@/lib/data-utils"
import { cn } from "@/lib/utils"

interface KPICardsProps {
  kpis: KPI[]
}

export function KPICards({ kpis }: KPICardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {kpis.map((kpi, index) => (
        <TooltipProvider key={index}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer bg-card border-border">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground truncate">
                    {kpi.name}
                  </CardTitle>
                  {kpi.changeType && (
                    <div
                      className={cn(
                        "flex items-center gap-1 text-xs font-medium rounded-full px-2 py-0.5",
                        kpi.changeType === "increase" &&
                          "text-emerald-600 bg-emerald-100 dark:text-emerald-400 dark:bg-emerald-950",
                        kpi.changeType === "decrease" &&
                          "text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-950",
                        kpi.changeType === "neutral" &&
                          "text-muted-foreground bg-muted"
                      )}
                    >
                      {kpi.changeType === "increase" && (
                        <TrendingUp className="h-3 w-3" />
                      )}
                      {kpi.changeType === "decrease" && (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      {kpi.changeType === "neutral" && (
                        <Minus className="h-3 w-3" />
                      )}
                      {kpi.change !== undefined && (
                        <span>{kpi.change.toFixed(1)}%</span>
                      )}
                    </div>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">
                    {kpi.value}
                  </div>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <p className="max-w-xs">{kpi.description}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ))}
    </div>
  )
}
